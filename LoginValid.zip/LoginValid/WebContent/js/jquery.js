$("#login").on('click',function(){
	var name=$("name").val();
	var pass=$("pass").val();
	
	if(name==""){
		$("#message").css("display","none");
		alert("user name is required");
		return;
		}
	if(pass==""){
		$("#pass").css("display","none");
		alert("user password is required");
	}
	$.ajax({
		url:"LoginRequest",
	    method:get,
	    data:{
	    	name:name,
	    	pass:pass
	    },
	    success:function(result){
	    	if(result!=null & result!=""){
	    		showMessage(result);
	    		$('#message').css("display","block");
	    	}
	    		else{
	    			$('#message').css("display","none");
	    			$('#message').html("");
	    			alert("Some exception occurred! Please try again...");
	    		
	    	}
	    }
	});
});

function showMessage(result){
	if(results == 'success'){
        $('#message').html("<font color='green'>You are successfully logged in. </font>")
    }else if(results == 'failure'){
        $('#message').html("<font color='red'>Username or password incorrect </font>")
    }
}